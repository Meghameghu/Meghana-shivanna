# ✅ INSTALL DEPENDENCIES (Run in terminal if needed)
# pip install ultralytics opencv-python pillow streamlit

import cv2
import numpy as np
from ultralytics import YOLO
import streamlit as st
from PIL import Image
import tempfile
import os

# === Load YOLOv8 Model ===
model = YOLO("yolov8n.pt")

# === Utility to Estimate Distance (Simple Heuristic) ===
def estimate_distance(bbox_height, frame_height):
    if bbox_height == 0:
        return float('inf')
    distance = (1 - (bbox_height / frame_height)) * 100
    return round(distance, 2)

# === Scene & Vehicle Keywords ===
scene_keywords = ["person", "cow", "dog", "cat", "sheep", "horse"]
vehicle_keywords = ["car", "truck", "bus", "motorcycle"]

# === Naive Indicator Light Detection Using Orange Color ===
def detect_indicators(frame, vehicle_boxes):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_orange = np.array([5, 100, 100])
    upper_orange = np.array([20, 255, 255])
    mask = cv2.inRange(hsv, lower_orange, upper_orange)
    indicators = []

    for (x1, y1, x2, y2) in vehicle_boxes:
        vehicle_roi = mask[y1:y2, x1:x2]
        contours, _ = cv2.findContours(vehicle_roi, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        for cnt in contours:
            cx, cy, w, h = cv2.boundingRect(cnt)
            cx += x1  # Offset to global coords
            cy += y1
            if w > 2 and h > 2:
                indicators.append((cx, cy))

    return indicators

# === Streamlit UI ===
st.set_page_config(layout="wide")
st.title("🚘 Autonomous Vehicle Alert System")

uploaded_file = st.file_uploader("Upload video or image", type=["mp4", "mov", "avi", "mkv", "jpg", "jpeg", "png"])

if uploaded_file is not None:
    file_type = uploaded_file.type

    tfile = tempfile.NamedTemporaryFile(delete=False)
    tfile.write(uploaded_file.read())
    tfile.close()

    def analyze_frame(frame):
        results = model(frame, verbose=False)[0]
        frame_height, frame_width = frame.shape[:2]
        alert_triggered = False
        boxes_detected = []
        labels_detected = []
        vehicle_boxes = []

        for box in results.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            cls = int(box.cls[0].item())
            label = model.names[cls]

            boxes_detected.append((x1, y1, x2, y2))
            labels_detected.append(label)
            if label in vehicle_keywords:
                vehicle_boxes.append((x1, y1, x2, y2))

            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

        indicator_points = detect_indicators(frame, vehicle_boxes)

        for (x1, y1, x2, y2), label in zip(boxes_detected, labels_detected):
            if label in vehicle_keywords:
                dist = estimate_distance(y2 - y1, frame_height)
                if dist < 30:
                    alert_triggered = True
                    cv2.putText(frame, f"ALERT: VEHICLE VERY CLOSE ({dist}m) - POTENTIAL COLLISION!", (30, 110),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            elif label in scene_keywords:
                dist = estimate_distance(y2 - y1, frame_height)
                if dist < 70:
                    alert_triggered = True
                    cv2.putText(frame, f"ALERT: {label.upper()} ahead in {dist}m - SLOW DOWN!", (30, 80),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

        for cx, cy in indicator_points:
            if cx < frame.shape[1] // 2:
                cv2.putText(frame, "LEFT INDICATOR ON → MOVE RIGHT", (30, 140),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 140, 255), 2)
            else:
                cv2.putText(frame, "RIGHT INDICATOR ON → MOVE LEFT", (30, 170),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 140, 255), 2)

        if not alert_triggered:
            cv2.putText(frame, "All Clear", (30, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

        return frame

    if "video" in file_type:
        cap = cv2.VideoCapture(tfile.name)
        FRAME_WINDOW = st.image([])

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            annotated = analyze_frame(frame)
            FRAME_WINDOW.image(cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB))
        cap.release()

    elif "image" in file_type:
        image = Image.open(tfile.name)
        frame = np.array(image)
        annotated = analyze_frame(frame)
        st.image(annotated, caption="Detected Image")
